export interface Server {
  id: number;
  name: string;
  status: string;
}
