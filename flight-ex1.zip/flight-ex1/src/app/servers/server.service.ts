import { Server } from './server.model';

export class ServerService {
  private servers: Server[] = [
    { id: 1, name: 'Test Server', status: 'offline' },
    { id: 2, name: 'Production Server', status: 'online' },
    { id: 1, name: 'statge server', status: 'offline' },
  ];
  getServers() {
    return this.servers;
  }
  getServer(id: number) {
    return this.servers.find((server) => server.id === id);
  }
}
