package com.ksr.bootstrap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.ksr.entities.Laptop;
import com.ksr.entities.Student;
import com.ksr.repositories.StudentRepository;
@Component
public class BootStrap implements CommandLineRunner{
	
	private StudentRepository studentRepository;
	@Autowired
	public BootStrap(StudentRepository studentRepository) {
		super();
		this.studentRepository = studentRepository;
	}

	@Override
	public void run(String... args) throws Exception {
		Laptop laptop=new Laptop();
		laptop.setCompany("Lenovo");
		laptop.setPrice(40000);
		Student student=new Student();
		student.setName("suresh");
		student.setAddress("Chennai");
		student.setLaptop(laptop);
		studentRepository.save(student);
	}

}
