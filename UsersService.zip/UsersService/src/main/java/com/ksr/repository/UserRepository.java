package com.ksr.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ksr.entities.UserEntity;

public interface UserRepository extends JpaRepository<UserEntity, Long>{
	UserEntity findByEmail(String email);
	UserEntity findByUserId(String userId);
}
