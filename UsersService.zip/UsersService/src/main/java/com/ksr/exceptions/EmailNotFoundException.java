package com.ksr.exceptions;

public class EmailNotFoundException extends Exception{
	public EmailNotFoundException(){
		
	}
	public EmailNotFoundException(String desc)
	{
		super();
	}
}
