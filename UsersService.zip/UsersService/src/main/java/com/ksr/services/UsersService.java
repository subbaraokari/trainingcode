package com.ksr.services;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.ksr.exceptions.EmailNotFoundException;
import com.ksr.shared.UserDto;

public interface UsersService  extends UserDetailsService{
	UserDto createUser(UserDto userDetails);
	UserDto getUserDetailsByEmail(String email) throws EmailNotFoundException;
	UserDto getUserByUserId(String userId);

}
