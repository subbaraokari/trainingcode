package com.ksr.services;

import java.util.List;

import com.ksr.entities.Emp;
import com.ksr.exceptions.EmployeeNotFoundException;

public interface EmpService {
	List<Emp> getEmployees();
	Emp getEmployee(int eno) throws EmployeeNotFoundException;
	Emp deleteEmployee(int eno) throws EmployeeNotFoundException;
	Emp insertEmployee(Emp e);

}
