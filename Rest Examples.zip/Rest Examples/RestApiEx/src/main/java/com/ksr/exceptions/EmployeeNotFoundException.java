package com.ksr.exceptions;

public class EmployeeNotFoundException extends Exception {
	public EmployeeNotFoundException() {
		// TODO Auto-generated constructor stub
	}
	public EmployeeNotFoundException(String desc) {
		super(desc);
	}
}
