package com.ksr.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ksr.entities.Emp;

public interface EmpRepository extends JpaRepository<Emp, Integer> {

}
