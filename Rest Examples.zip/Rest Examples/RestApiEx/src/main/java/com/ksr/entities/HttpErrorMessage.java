package com.ksr.entities;

import java.util.Date;

import org.springframework.http.HttpStatus;

public class HttpErrorMessage {
	private String message;
	private Date date;
	private HttpStatus status;
	public HttpErrorMessage() {
		// TODO Auto-generated constructor stub
	}
	public HttpErrorMessage(String message, Date date, HttpStatus status) {
		super();
		this.message = message;
		this.date = date;
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public HttpStatus getStatus() {
		return status;
	}
	public void setStatus(HttpStatus status) {
		this.status = status;
	}
	
}
