package com.ksr.controllers;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ksr.entities.Emp;
import com.ksr.exceptions.EmployeeNotFoundException;
import com.ksr.services.EmpService;

@RestController
@RequestMapping("/api/v1/employees")
public class EmpController {
	private EmpService empService;
	public EmpController(EmpService empService) {
		super();
		this.empService = empService;
	}
	@GetMapping
	public ResponseEntity<List<Emp>> getEmployees(){
		List<Emp> employees=empService.getEmployees();
		return new ResponseEntity<List<Emp>>(employees, HttpStatus.OK);
	}
	@GetMapping("/{id}")
	public ResponseEntity<Emp> getEmployee(@PathVariable("id") int eno) throws EmployeeNotFoundException{
		Emp e=empService.getEmployee(eno);
		return new ResponseEntity<Emp>(e,HttpStatus.OK);
	}
	@PostMapping
	public ResponseEntity<Emp> insertEmployee(@RequestBody Emp e){
		Emp e1=empService.insertEmployee(e);
		return new ResponseEntity<Emp>(e1,HttpStatus.CREATED);
	}
	@DeleteMapping("/{id}")
	public Emp deleteEmployee(@PathVariable("id") int eno) throws EmployeeNotFoundException {
		Emp e=empService.deleteEmployee(eno);
		return e;
	}
}
