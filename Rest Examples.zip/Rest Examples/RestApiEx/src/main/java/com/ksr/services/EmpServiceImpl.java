package com.ksr.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ksr.entities.Emp;
import com.ksr.exceptions.EmployeeNotFoundException;
import com.ksr.repos.EmpRepository;
@Service
public class EmpServiceImpl implements EmpService {
	EmpRepository repository;
	
	
	public EmpServiceImpl(EmpRepository repository) {
		super();
		this.repository = repository;
	}

	@Override
	public List<Emp> getEmployees() {
		return repository.findAll();
	}

	@Override
	public Emp getEmployee(int eno) throws EmployeeNotFoundException {
		Emp e=repository.findById(eno).orElseThrow(()->new EmployeeNotFoundException("Employee not found"));
		return e;
	}

	@Override
	public Emp deleteEmployee(int eno) throws EmployeeNotFoundException {
		Emp e=repository.findById(eno).orElseThrow(()->new EmployeeNotFoundException("Employee not found"));
		repository.delete(e);
		return e;
	}

	@Override
	public Emp insertEmployee(Emp e) {
		Emp e1=repository.save(e);
		return e1;
	}

}
