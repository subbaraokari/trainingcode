package com.ksr.controllers;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.ksr.entities.HttpErrorMessage;
import com.ksr.exceptions.EmployeeNotFoundException;

@RestControllerAdvice
public class GlobalExceptionHandler {
	@ExceptionHandler(EmployeeNotFoundException.class)
	public ResponseEntity<HttpErrorMessage> handleEmployeeNotFoundException(EmployeeNotFoundException ex){
		HttpErrorMessage errorMessage=new HttpErrorMessage(ex.getMessage(), new Date(), HttpStatus.BAD_REQUEST);
		return new ResponseEntity<HttpErrorMessage>(errorMessage,HttpStatus.BAD_REQUEST);
	}
	@ExceptionHandler(Exception.class)
	public ResponseEntity<HttpErrorMessage> handleOtherException(Exception ex){
		HttpErrorMessage errorMessage=new HttpErrorMessage(ex.getMessage(), new Date(), HttpStatus.BAD_REQUEST);
		return new ResponseEntity<HttpErrorMessage>(errorMessage,HttpStatus.BAD_REQUEST);
	}
}
