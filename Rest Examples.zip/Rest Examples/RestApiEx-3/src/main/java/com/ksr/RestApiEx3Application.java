package com.ksr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestApiEx3Application {

	public static void main(String[] args) {
		SpringApplication.run(RestApiEx3Application.class, args);
	}

}
