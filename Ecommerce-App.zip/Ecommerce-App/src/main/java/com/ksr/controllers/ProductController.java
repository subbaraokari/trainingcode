package com.ksr.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ksr.entities.Product;
import com.ksr.entities.User;
import com.ksr.repositories.ProductRepository;
import com.ksr.repositories.UserRepository;
import com.ksr.services.ProductService;

@RestController
@RequestMapping("/products")
public class ProductController {
	private ProductService productService;
	@Autowired
	public ProductController(ProductService productService) {
		super();
		this.productService = productService;
	}

	@PostMapping
	public ResponseEntity addProduct(@RequestParam("username") String username,@RequestBody Product product){
		productService.addProduct(username, product);
		return new ResponseEntity(HttpStatus.CREATED);
	}
}
