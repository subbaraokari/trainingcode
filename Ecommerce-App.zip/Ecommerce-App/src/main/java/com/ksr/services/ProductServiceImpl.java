package com.ksr.services;

import org.springframework.stereotype.Service;

import com.ksr.entities.Product;
import com.ksr.entities.User;
import com.ksr.repositories.ProductRepository;
import com.ksr.repositories.UserRepository;
@Service
public class ProductServiceImpl implements ProductService {
	private UserRepository userRepository;
	private ProductRepository productRepository;
	
	public ProductServiceImpl(UserRepository userRepository, ProductRepository productRepository) {
		super();
		this.userRepository = userRepository;
		this.productRepository = productRepository;
	}
	@Override
	public void addProduct(String username,Product product) {
		User user=userRepository.findByUserName(username);
		if(user.getRole()=="admin")
		{
			user.addProduct(product);
			product.setUser(user);
			userRepository.save(user);
		}
	}

}
