package com.ksr.services;

import org.springframework.stereotype.Service;

import com.ksr.entities.User;
import com.ksr.exceptions.UserNotFoundException;
import com.ksr.model.AuthReponse;
import com.ksr.repositories.UserRepository;
@Service
public class UserServiceImpl implements UserService {
	private UserRepository userRepo;
	
	public UserServiceImpl(UserRepository userRepo) {
		super();
		this.userRepo = userRepo;
	}

	@Override
	public User registerUser(User user) {
		User user1=userRepo.save(user);
		return user;
	}

	@Override
	public AuthReponse validate(User user) throws UserNotFoundException {
		AuthReponse authReponse = null;
		User user1=userRepo.findByUserNameAndPassword(user.getUserName(), user.getPassword());
		if(user1!=null) {
			authReponse=new AuthReponse();
			authReponse.setUserName(user1.getUserName());
			authReponse.setAuthenticationStatus(true);
			return authReponse;
		}
		else
		{
			throw new UserNotFoundException("User not found with username and password");
		}
	}

}
