package com.ksr.services;

import com.ksr.entities.Product;

public interface ProductService {
	void addProduct(String username,Product product);
}
