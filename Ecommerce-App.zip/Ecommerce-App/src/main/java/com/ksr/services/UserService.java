package com.ksr.services;

import com.ksr.entities.User;
import com.ksr.exceptions.UserNotFoundException;
import com.ksr.model.AuthReponse;

public interface UserService {
	User registerUser(User user);
	AuthReponse validate(User user) throws UserNotFoundException;
}
