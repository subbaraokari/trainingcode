package com.ksr.model;

public class AuthReponse {
	private String userName;
	private boolean authenticationStatus;
	public AuthReponse() {
		// TODO Auto-generated constructor stub
	}
	public AuthReponse(String userName, boolean authenticationStatus) {
		super();
		this.userName = userName;
		this.authenticationStatus = authenticationStatus;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public boolean isAuthenticationStatus() {
		return authenticationStatus;
	}
	public void setAuthenticationStatus(boolean authenticationStatus) {
		this.authenticationStatus = authenticationStatus;
	}
	

}
