package com.ksr.controllers;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.reflect.TypeToken;
import com.ksr.entities.AlbumEntity;
import com.ksr.model.AlbumResponseModel;
import com.ksr.services.AlbumService;

@RestController
@RequestMapping("/albums")
public class AlbumController {
	AlbumService albumService;
	@Autowired
	public AlbumController(AlbumService albumService) {
		super();
		this.albumService = albumService;
	}

	@GetMapping("/{id}")
	public List<AlbumResponseModel> getAlbums(@PathVariable("id") String userId){
		List<AlbumResponseModel> returnValue=new ArrayList<>();
		List<AlbumEntity> albumEntities=albumService.getAlbums(userId);
		Type listType=new TypeToken<List<AlbumResponseModel>>() {
		}.getType();
		returnValue=new ModelMapper().map(albumEntities, listType);
		return returnValue;
	}
}
