package com.ksr.services;

import java.util.List;

import com.ksr.entities.AlbumEntity;

public interface AlbumService {
	List<AlbumEntity> getAlbums(String userId);
}
