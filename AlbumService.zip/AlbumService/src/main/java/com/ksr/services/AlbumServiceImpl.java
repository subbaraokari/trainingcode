package com.ksr.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.ksr.entities.AlbumEntity;
@Service
public class AlbumServiceImpl implements AlbumService {

	@Override
	public List<AlbumEntity> getAlbums(String userId) {
		List<AlbumEntity> albums=new ArrayList<>();
		AlbumEntity albumEntity1=new AlbumEntity();
		albumEntity1.setUserId(userId);
		albumEntity1.setAlbumId("albumid1");
		albumEntity1.setDescription("album1 description");
		albumEntity1.setId(1L);
		albumEntity1.setName("Album1 name");
		
		AlbumEntity albumEntity2=new AlbumEntity();
		albumEntity2.setUserId(userId);
		albumEntity2.setAlbumId("albumid2");
		albumEntity2.setDescription("album2 description");
		albumEntity2.setId(2L);
		albumEntity2.setName("Album2 name");
		albums.add(albumEntity1);
		albums.add(albumEntity2);
		return albums;
	}

}
