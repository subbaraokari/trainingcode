import { Recipe } from './recipe.model';

export class RecipeService {
  private recipes: Recipe[] = [
    {
      id: 1,
      name: 'Burger',
      description: 'dshgdhsagdusagdiugsa dasd ',
      imageUrl:
        'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=602&q=80',
    },
    {
      id: 2,
      name: 'Sandwitch',
      description: 'dshgdhsagdusagdiugsa dasd ',
      imageUrl:
        'https://images.unsplash.com/photo-1613482083855-2e5e73168270?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=889&q=80',
    },
    {
      id: 3,
      name: 'Pizza',
      description: 'dshgdhsagdusagdiugsa dasd ',
      imageUrl:
        'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8cGl6emF8ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60',
    },
  ];
  getRecipes() {
    return this.recipes;
  }
}
