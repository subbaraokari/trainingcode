package com.ksr.bootstrap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.ksr.entities.Course;
import com.ksr.entities.Student;
import com.ksr.repository.StudentRepository;
@Component
public class BootStrap implements CommandLineRunner {
	private StudentRepository studentRepository;
	@Autowired
	public BootStrap(StudentRepository studentRepository) {
		super();
		this.studentRepository = studentRepository;
	}

	@Override
	public void run(String... args) throws Exception {
		Course c1=new Course();
		Student student=new Student();
		student.setName("Raja");
		student.setAddress("Chennai");
		c1.setCname("Java");
		c1.setFee(10000);
		c1.setStudent(student);
		Course c2=new Course();
		c2.setCname("python");
		c2.setFee(8000);
		c2.setStudent(student);
		student.addCourse(c1);
		student.addCourse(c2);
		studentRepository.save(student);
		
		
		
		
	}

}
