package org.cts;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.Scanner;

public class InsertDemo1 {

	public static void main(String[] args) {
		Connection con=null;
		PreparedStatement pst=null;
		Scanner sc=new Scanner(System.in);
		try {
			//Loading a driver .class file
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/testdb2","root","root");
			if(con!=null)
			{
				pst=con.prepareStatement("insert into emp values(?,?,?)");
				System.out.println("enter the employee no");
				int eno=sc.nextInt();
				sc.nextLine();
				
				System.out.println("enter the name");
				String name=sc.nextLine();
				System.out.println("enter the address");
				String address=sc.nextLine();
				pst.setInt(1, eno);
				pst.setString(2, name);
				pst.setString(3, address);
				int i=pst.executeUpdate();
				if(i>0)
					System.out.println("data inserted successfully");
				else
					System.out.println("not inserted");
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

}
