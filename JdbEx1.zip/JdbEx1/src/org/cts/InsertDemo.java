package org.cts;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class InsertDemo {
	public static void main(String[] args) {
		Connection con=null;
		Statement st=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/testdb2","root","root");
			if(con!=null)
			{
				st=con.createStatement();
				String sql="insert into emp values(3,'vamsi','Hyd')";
				int i=st.executeUpdate(sql);
				if(i>0)
					System.out.println("Successfully inserted");
				else
					System.out.println("Not inserted");
				st.close();
			}
			
			con.close();
		} catch (Exception e) {
			try {
				con.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
}
