package org.cts.dao;

import java.util.List;

import org.cts.entities.Emp;

public interface EmpDao {
	boolean insertEmployee(Emp e);
	boolean deleteEmployee(int eno);
	List<Emp> getEmployees();
	Emp getEmployee(int eno);
}
