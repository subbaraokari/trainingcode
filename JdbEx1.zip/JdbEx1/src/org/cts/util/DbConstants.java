package org.cts.util;

public class DbConstants {
	public static final String DRIVER="com.mysql.cj.jdbc.Driver";
	public static final String URL="jdbc:mysql://localhost:3306/testdb2";
	public static final String UNAME="root";
	public static final String PASSWORD="root";
}
