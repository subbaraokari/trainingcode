import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  user: { email: string; password: string } = {
    email: '',
    password: '',
  };
  constructor() {}

  ngOnInit(): void {}
  onSubmit(form: NgForm) {
    console.log(form);
    this.user.email = form.value.email;
    this.user.password = form.value.password;
    console.log(this.user);
  }
}
